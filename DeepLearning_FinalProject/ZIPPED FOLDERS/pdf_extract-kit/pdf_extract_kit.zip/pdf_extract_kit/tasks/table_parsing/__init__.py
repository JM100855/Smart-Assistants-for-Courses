from pdf_extract_kit.tasks.table_parsing.models.struct_eqtable import TableParsingStructEqTable

from pdf_extract_kit.registry.registry import MODEL_REGISTRY

__all__ = [
    "TableParsingStructEqTable",
]
