from pdf_extract_kit.tasks.formula_detection.models.yolo import FormulaDetectionYOLO

from pdf_extract_kit.registry.registry import MODEL_REGISTRY

__all__ = [
    "FurmulaDetectionYOLO",
]
