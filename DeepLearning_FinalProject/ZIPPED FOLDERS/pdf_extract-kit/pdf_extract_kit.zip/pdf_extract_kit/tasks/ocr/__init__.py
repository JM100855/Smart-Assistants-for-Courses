from pdf_extract_kit.tasks.ocr.models.paddle_ocr import ModifiedPaddleOCR
# from pdf_extract_kit.registry.registry import MODEL_REGISTRY


__all__ = [
    "ModifiedPaddleOCR",
]
