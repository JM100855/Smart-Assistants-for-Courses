<!--

## vX.X.X (YYYY.MM.DD)

### 亮点

### 新功能和改进

### Bug 修复

### 贡献者

-->

# 变更日志


## v0.2.0 (2024.09.30)

PDF-Extract-Kit 代码重构，模块化设计更加简洁易用! 🔥🔥🔥

## v0.1.0 (2024.07.01)

PDF-Extract-Kit 正式发布！🔥🔥🔥

### 亮点

- PDF-Extract-Kit提供高质量布局检测模型 DocLayout-YOLO
- PDF-Extract-Kit提供高质量公式检测模型 YOLOv8