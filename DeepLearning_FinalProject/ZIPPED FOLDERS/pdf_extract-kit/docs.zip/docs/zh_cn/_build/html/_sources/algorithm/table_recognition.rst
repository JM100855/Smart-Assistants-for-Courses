..  _algorithm_table_recognition:
=================
表格识别算法
=================

Comming soon.