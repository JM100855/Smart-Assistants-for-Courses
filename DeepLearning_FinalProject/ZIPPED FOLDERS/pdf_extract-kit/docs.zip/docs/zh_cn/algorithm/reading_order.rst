..  _algorithm_reading_oder:
==============
阅读顺序算法
==============

Comming soon.