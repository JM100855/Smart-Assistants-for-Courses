<!--

## vX.X.X (YYYY.MM.DD)

### 亮点

### 新功能和改进

### Bug 修复

### 贡献者

-->

# Changelog

## v1.0.0 (2024-10-10)

The PDF-Extract-Kit-1.0 has been refactored with a more streamlined and user-friendly modular design! 🔥🔥🔥

## v0.1.0 (2024-07-01)

Official release of PDF-Extract-Kit! 🔥🔥🔥

### Highlights

- PDF-Extract-Kit-1.0 offers a high-quality layout detection model, DocLayout-YOLO.