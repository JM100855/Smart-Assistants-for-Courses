..  _algorithm_reading_oder:
==============
Reading Order Algorithm
==============

Comming soon.