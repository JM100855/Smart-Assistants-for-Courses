=====================
Formula Recognition Evaluation
=====================

XXX