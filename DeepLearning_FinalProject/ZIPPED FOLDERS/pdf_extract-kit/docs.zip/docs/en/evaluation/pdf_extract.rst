=====================
PDF Content Extraction Evaluation [End-to-End]
=====================

XXX