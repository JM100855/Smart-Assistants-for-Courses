=====================
Reading Order Evaluation
=====================

XXX