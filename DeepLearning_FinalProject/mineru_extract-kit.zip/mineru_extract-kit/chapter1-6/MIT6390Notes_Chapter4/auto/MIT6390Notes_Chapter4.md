CHAPTER 4  

# 4.1 Classification  

Classification is a machine learning problem seeking to map from inputs $\mathbb{R}^{\mathrm{d}}$ to outputs in an unordered set. Examples of classification output sets could be {a pples , o ranges , p ears }if we’re trying to figure out what type of fruit we have, or {heartattack , n oheartattack }if we’re working in an emergency room and trying to give the best medical care to a new patient. We focus on an essential simple case, binary classification , where we aim to find a mapping from $\mathbb{R}^{\mathrm{d}}$ to two outputs. While we should think of the outputs as not having an order, it’s often convenient to encode them as $\{-1,+1\}$ . As before, let the letter $\mathtt{h}$ (for hypothesis) represent a classifier, so the classification process looks like:  

in contrast to a continuous real-valued output, as we saw for linear regression  

$$
{\bf x}\rightarrow\boxed{\bf h}\boxed{\bf\to}{\bf y}\;\;.
$$  

Like regression, classification is a supervised learning problem, in which we are given a training data set of the form  

$$
\mathcal{D}_{\mathfrak{n}}=\left\{\left(x^{(1)},\mathfrak{y}^{(1)}\right),\ldots,\left(x^{(\mathfrak{n})},\mathfrak{y}^{(\mathfrak{n})}\right)\right\}\ .
$$  

We will assume that each $x^{(\mathrm{i})}$ is a $\mathrm{d}\times1$ column vector . The intended meaning of this data is that, when given an input $x^{(\mathrm{i})}$ , the learned hypothesis should generate output $\mathfrak{y}^{(\mathrm{i})}$ .  

What makes a classifier useful? As in regression, we want it to work well on new data, making good predictions on examples it hasn’t seen. But we don’t know exactly what data this classifier might be tested on when we use it in the real world. So, we have to assume a connection between the training data and testing data; typically, they are drawn independently from the same probability distribution.  

In classification, we will often use 0-1 loss for evaluation (as discussed in Section 1.3). For that choice, we can write the training error and the testing error. In particular, given a training set $\mathbb{D}_{\mathfrak{n}}$ and a classifier $^{\mathrm{h,}}$ we define the training error of $\mathtt{h}$ to be  

$$
\mathcal{E}_{\mathfrak{n}}({\mathsf{h}})=\frac{1}{\mathfrak{n}}\sum_{\mathrm{i=1}}^{\mathfrak{n}}\left\{1\quad\mathsf{h}({\mathsf{x}}^{(\mathrm{i})})\neq\mathfrak{y}^{(\mathrm{i})}\right.\right.\,.
$$  

For now, we will try to find a classifier with small training error (later, with some added criteria) and hope it generalizes well to new data, and has a small test error  

$$
\mathcal{E}(\mathbf{h})=\frac{1}{\mathfrak{n}^{\prime}}\sum_{\mathrm{i=n+1}}^{\mathfrak{n}+\mathfrak{n}^{\prime}}\left\{1\quad\mathsf{h}(\mathfrak{x}^{(\mathrm{i})})\neq\mathfrak{y}^{(\mathrm{i})}\right.
$$  

on $\mathfrak{n^{\prime}}$ new examples that were not used in the process of finding the classifier.  

We begin by introducing the hypothesis class of linear classifiers (Section 4.2) and then define an optimization framework to learn linear logistic classifiers (Section 4.3).  

# 4.2 Linear classifiers  

We start with the hypothesis class of linear classifiers . They are (relatively) easy to understand, simple in a mathematical sense, powerful on their own, and the basis for many other more sophisticated methods. Following their definition, we present a simple learning algorithm for classifiers.  

# 4.2.1 Linear classifiers: definition  

A linear classifier in ddimensio s is defined by a vector of parameters $\uptheta\,\in\,\mathbb{R}^{\mathrm{d}}$ and scalar $\uptheta_{0}\in\mathbb{R}$ . So, the hypoth lass $\mathcal{H}$ of linear clas fiers dimensions is parameterized by the set of all vectors in $\mathbb{R}^{\mathbf{d}+1}$ . We’ll assume that θis a $\mathrm{d}\times1$ ×1 column vector.  

Given particular values for θand $\uptheta_{0}$ , the classifier is defined by  

$$
{\displaystyle\mathrm{h}(x;\theta,\theta_{0})=\mathrm{sign}(\theta^{\top}x+\theta_{0})=\left\{+1\quad\mathrm{if}\ \theta^{\top}x+\theta_{0}>0}\\ {-1\quad\mathrm{otherwise}}\end{array}\right.}.
$$  

Remember that we can think of $\uptheta,\uptheta_{0}$ as specifying a $\mathrm{d}$ -dimensional hyperplane (compare the above with Eq. 2.3). But this time, rather than being interested in that hyperplane’s values at particular points $x,$ we will focus on the separator that it induces. The separator is the set of $x$ values such that $\uptheta^{\top}\up x\,{+}\,\theta_{0}=0$ . This is also a hyperplane, but in $_{\mathrm{d}-1}$ dimensions! We can interpret $\uptheta$ as a vector that is perpendicular to the separator. (We will also say that $\uptheta$ is normal to the separator.)  

For example, in two dimensions $[\mathrm{d}=2]$ ) the separator has dimension 1, which means it is a line, and the two components of $\boldsymbol{\theta}=[\theta_{1},\theta_{2}]^{\top}$ give the orientation of the separator, as illustrated in the following example.  

Example: Let hbe the linear classifier defined by ${\mathfrak{\theta}}=\left[{\!\!\begin{array}{l}{1}\\ {-1}\end{array}}\right],{\mathfrak{\theta}}_{0}=1.$  

The diagram below shows the θvector (in green) and the separator it defines:  

![](images/6f378dd3be60d010dd284d4dba0d488d5184bdd5279e9006206be57d2417daa7.jpg)  

What is $\theta_{0}?$ We can solve for it by plugging a point on the line into the equation for the line. It is often convenient to choose a point on one of the axes, e.g., in this case, ${\boldsymbol{x}}=[0,1]^{\mathsf{T}}$ , for which θ$\boldsymbol{\mathfrak{I}}^{\intercal}\left[\begin{array}{l}{0}\\ {1}\end{array}\right]+\boldsymbol{\mathfrak{0}}_{0}=0,$ 0, giving $\uptheta_{0}=1$ .  

In this example, the separator divides $\mathbb{R}^{\mathrm{d}}$ , the space our $x^{(\mathrm{i})}$ points live in, into two halfspaces. The one that is on the same side as the normal vector is the positive half-space, and we classify all points in that space as positive. The half-space on the other side is negative and all points in it are classified as negative.  

Note that we will call a separator a linear separator of a data set if all of the data with one label falls on one side of the separator and all of the data with the other label falls on the other side of the separator. For instance, the separator in the next example is a linear separator for the illustrated data. If there exists a linear separator on a dataset, we call this dataset linearly separable .  

Example: Let hbe the linear classifier defined by $\begin{array}{c c c}{\displaystyle{\theta=\left[\!\!\begin{array}{c}{\!\!-1\!\!}\\ {\!\!1.5\!\!}\end{array}\!\!\right],\theta_{0}=3.}}\end{array}$ The diagram below shows several points classified by $\mathtt{h}$ . In particular, let $\mathsf{x}^{(1)}=\binom{3}{2}$ and $\mathbf{\Deltax}^{(2)}=\left[\!\!\begin{array}{l}{{4}}\\ {{-1}}\end{array}\!\!\right]$ .  

$$
\begin{array}{r l}&{\mathtt{h}(x^{(1)};\theta,\theta_{0})=\mathrm{sign}\left(\left[-1\right.\right.\left.1.5\right]\left[\!\!\left[2\right]\!\!+\!3\right)=\mathrm{sign}(3)=+1}\\ &{\mathtt{h}(x^{(2)};\theta,\theta_{0})=\mathrm{sign}\left(\left[\!\!\left[-1\right.\right.\left.1.5\right]\left[\!\!\left.\frac{4}{-1}\right]+3\right)=\mathrm{sign}(-2.5)=-1}\end{array}
$$  

Thus, $x^{(1)}$ and $x^{(2)}$ are given positive and negative classifications, respectively.  

![](images/223eac3a56206f9892d7372efaa78ca5d40d3b0874ed17fe6d9191adf174c636.jpg)  

Study Question: What is the green vector normal to the separator? Specify it as a column vector.  

Study Question: What change would you have to make to $\uptheta,\uptheta_{0}$ if you wanted to have the separating hyperplane in the same place, but to classify all the points labeled $^{\prime}+^{\prime}$ in the diagram as negative and all the points labeled ’-’ in the diagram as positive?  

# 4.3 Linear logistic classifiers  

Given a data set and the hypothesis class of linear classifiers, our goal will be to find the linear classifier that optimizes an objective function relating its predictions to the training data. To make this problem computationally reasonable, we will need to take care in how we formulate the optimization problem to achieve this goal.  

For classification, it is natural to make predictions in $\{+1,-1\}$ and use the 0-1 loss function, ${\mathcal{L}}_{01},$ as introduced in Chapter 1:  

$$
\mathcal{L}_{01}(\mathbf{g},\mathbf{a})=\left\{\begin{array}{l l}{0}&{\mathrm{if}\ g=\mathbf{a}}\\ {1}&{\mathrm{otherwise}}\end{array}\right..
$$  

However, even for simple linear classifiers, it is very difficult to find values for $\uptheta,\uptheta_{0}$ that minimize simple 0-1 training error  

$$
\boldsymbol{\mathrm{J}}(\boldsymbol{\theta},\boldsymbol{\theta}_{0})=\frac{1}{\mathfrak{n}}\sum_{\mathrm{i}=1}^{\mathfrak{n}}\mathcal{L}_{01}(\mathrm{sign}(\boldsymbol{\theta}^{\mathsf{T}}\boldsymbol{x}^{(\mathrm{i})}+\boldsymbol{\theta}_{0}),\boldsymbol{\mathfrak{y}}^{(\mathrm{i})})\ \mathrm{.}
$$  

This problem is NP-hard, which probably implies that solving the most difficult instances of this problem would require computation time exponential in the number of training examples, n.  

What makes this a difficult optimization problem is its lack of “smoothness”:  

• There can be two hypotheses, $\left(\uptheta,\uptheta_{0}\right)$ and $(\theta^{\prime},\theta_{0}^{\prime})$ , where one is closer in parameter space to the optimal parameter values $(\theta^{*},\theta_{0}^{*})$ , but they make the same number of misclassifications so they have the same Jvalue. • All predictions are categorical: the classifier can’t express a degree of certainty about whether a particular input $x$ should have an associated value $\boldsymbol{\mathfrak{y}}$ .  

The “probably” here is not because we’re too lazy to look it up, but actually because of a fundamental unsolved problem in computerscience theory, known as “P vs. NP.”  

For these reasons, if we are considering a hypothesis $\uptheta,\uptheta_{0}$ that makes five incorrect predictions, it is difficult to see how we might change $\uptheta,\uptheta_{0}$ so that it will perform better, which makes it difficult to design an algorithm that searches in a sensible way through the space of hypotheses for a good one. For these reasons, we investigate another hypothesis class: linear logistic classifiers , providing their definition, then an approach for learning such classifiers using optimization.  

# 4.3.1 Linear logistic classifiers: definition  

The hypotheses in a linear logistic classifier (LLC) are parameterized by a d-dimensional vector $\uptheta$ and a scalar $\uptheta_{0},$ , just as is the case for linear classifiers. However, instead of making predictions in $\{+1,-1\}_{.}$ , LLC hypotheses generate real-valued outputs in the interval $(0,1)$ .An LLC has the form  

$$
\mathrm{h}(\mathrm{x};\theta,\theta_{0})=\sigma(\theta^{\top}\mathrm{x}+\theta_{0})\;\;.
$$  

This looks familiar! What’s new?  

The logistic function, also known as the sigmoid function, is defined as  

$$
\sigma(z)=\frac{1}{1+e^{-z}}\;\;,
$$  

and is plotted below, as a function of its input $z$ . Its output can be interpreted as a probability, because for any value of $z$ the output is in $(0,1)$ .  

![](images/b6315f62c8126fd7c558bb3e1e9b340dedc55e382742bba6dbe57f1aab8a3e42.jpg)  

Study Question: Convince yourself the output of $\upsigma$ is always in the interval $(0,1)$ .Why can’t it equal 0 or equal 1? For what value of $z$ does $\sigma(z)=0.5?$  

What does an LLC look like? Let’s consider the simple case where $\mathtt{d}=1$ , so our input points simply lie along the $x$ axis. Classifiers in this case have dimension 0, meaning that they are points. The plot below shows LLCs for three different parameter settings: $\upsigma(10x+$ 1 ),$\sigma(-2x+1)$ , and ${\upsigma}(2x-3)$ .  

![](images/1dcf6127bd8aa27872e10c296ebcbfe8bcffd1dd734305478fc2586c41dcf857.jpg)  

Study Question: Which plot is which? What governs the steepness of the curve? What governs the $x$ value where the output is equal to 0.5?  

But wait! Remember that the definition of a classifier is that it’s a mapping from $\mathbb{R}^{\mathrm{d}}\,\rightarrow$ $\{-1,+1\}$ or to some other discrete set. $S\mathrm{o},$ then, it seems like an LLC is actually not a classifier!  

Given an LLC, with an output value in $(0,1)$ , what should we do if we are forced to make a prediction in $\{+1,-1\}?$ A default answer is to predict $+1$ if $\upsigma(\Theta^{\mathsf{T}}\mathsf{x}+\theta_{0})>0.5$ and $-1$ otherwise. The value 0.5 is sometimes called a prediction threshold .  

In fact, for different problem settings, we might prefer to pick a different prediction threshold. The field of decision theory considers how to make this choice. For example, if the consequences of predicting $+1$ when the answer should be $-1$ are much worse than the consequences of predicting $-1$ when the answer should be $+1$ , then we might set the prediction threshold to be greater than 0.5.  

Study Question: Using a prediction threshold of 0.5, for what values of $x$ do each of the LLCs shown in the figure above predict $+1?$  

When ${\tt d}=2$ , then our inputs $x$ lie in a two-dimensional space with axes $x_{1}$ and $x_{2},$ and the output of the LLC is a surface, as shown below, for $\theta=(1,1),\theta_{0}=2.$ .  

![](images/2073f04776223207456206464d6aca8db0a4c7faeba55560ad459de7dd15ad54.jpg)  

Study Question: Convince yourself that the set of points for which $\begin{array}{r}{\sigma({\boldsymbol{\theta}}^{\mathsf{T}}{\boldsymbol{x}}+{\boldsymbol{\theta}}_{0})=0.5,}\end{array}$ that is, the “boundary” between positive and negative predictions with prediction threshold 0.5, is a line in $\left(x_{1},x_{2}\right)$ space. What particular line is it for the case in the figure above? How would the plot change for $\theta=(1,1)$ , but now with $\theta_{0}=-2?$ For $\theta=(-1,-1),\theta_{0}=2?$  

# 4.3.2 Learning linear logistic classifiers  

Optimization is a key approach to solving machine learning problems; this also applies to learning linear logistic classifiers (LLCs) by defining an appropriate loss function for optimization. A first attempt might be to use the simple 0-1 loss function $\mathcal{L}_{01}$ that gives a value of 0 for a correct prediction, and a 1 for an incorrect prediction. As noted earlier, however, this gives rise to an objective function that is very difficult to optimize, and so we pursue another strategy for defining our objective.  

For learning LLCs, we’d have a class of hypotheses whose outputs are in $(0,1)$ , but for which we have training data with $\boldsymbol{\mathfrak{y}}$ values in $\{+1,-1\}$ . How can we define an appropriate loss function? We start by changing our interpretation of the output to be the probability that the input should map to output value 1 (we might also say that this is the probability that the input is in class 1 or that the input is ‘positive.’)  

Study Question: If $h(x)$ is the probability that $x$ belongs to class $+1$ , what is the probability that $x$ belongs to the class -1? Assuming there are only these two classes.  

Intuitively, we would like to have low loss if we assign a high probability to the correct class. We’ll define a loss function, called negative log-likelihood (NLL), that does just this. In addition, it has the cool property that it extends nicely to the case where we would like to classify our inputs into more than two classes.  

In order to simplify the description, we assume that (or transform our data so that) the labels in the training data are ${\mathfrak{y}}\in\{0,1\}$ .  

We would like to pick the parameters of our classifier to maximize the probability assigned by the LLC to the correct $\boldsymbol{\mathfrak{y}}$ values, as specified in the training set. Letting guess $\mathfrak{g}^{(\mathfrak{i})}=\sigma(\mathfrak{d}^{\mathsf{T}}\mathfrak{x}^{(\mathfrak{i})}+\mathfrak{d}_{0}).$ , that probability is  

Remember to be sure your yvalues have this form if you try to learn an LLC using NLL!  

That crazy huge Πrepresents taking the product over a bunch of factors just as huge Σrepresents taking the sum over a bunch of terms.  

$$
\prod_{\mathrm{i=1}}^{\mathrm{n}}\left\{{\mathfrak{g}}^{(\mathrm{i})}\qquad\mathrm{if~\mathfrak{y}^{(\mathrm{i})}=1~}\right.\,,
$$  

under the assumption that our predictions are independent. This can be cleverly rewritten, when $\mathfrak{y}^{(\mathrm{i})}\in\{0,1\}$ , as  

$$
\prod_{\mathrm{i=1}}^{\mathrm{n}}g^{(\mathrm{i})^{\flat^{(\mathrm{i})}}}(1-g^{(\mathrm{i})})^{1-\ y^{(\mathrm{i})}}\ \ .
$$  

Study Question: Be sure you can see why these two expressions are the same.  

The big product above is kind of hard to deal with in practice, though. So what can we do? Because the log function is monotonic, the θ,$\uptheta_{0}$ that maximize the quantity above will be the same as the $\uptheta,\uptheta_{0}$ that maximize its log, which is the following:  

$$
\sum_{\mathrm{i}=1}^{\mathrm{n}}\left(\mathfrak{y}^{(\mathrm{i})}\log\mathfrak{g}^{(\mathrm{i})}+(1-\mathfrak{y}^{(\mathrm{i})})\log(1-\mathfrak{g}^{(\mathrm{i})})\right)\ .
$$  

Finally, we can turn the maximization problem above into a minimization problem by tak  

ing the negative of the above expression, and write in terms of minimizing a loss  

$$
\sum_{\mathrm i=1}^{\mathrm n}\mathcal L_{\mathrm{nll}}(\boldsymbol{\mathfrak g}^{(\mathrm i)},\boldsymbol{\mathfrak y}^{(\mathrm i)})
$$  

where $\mathcal{L}_{\mathrm{nll}}$ is the negative log-likelihood loss function:  

$$
\mathscr{L}_{\mathrm{nll}}(\mathrm{guess,actual})=-\left(\mathrm{actual}\cdot\mathrm{log}(\mathrm{guess})+\left(1-\mathrm{actual}\right)\cdot\mathrm{log}(1-\mathrm{guess})\right)~~.
$$  

This loss function is also sometimes referred to as the log loss or cross entropy .  

What is the objective function for linear logistic classification? We can finally put all these pieces together and develop an objective function for optimizing regularized negative log-likelihood for a linear logistic classifier. In fact, this process is usually called “logistic regression,” so we’ll call our objective $\,\,\mathrm{J}_{\mathrm{lr}},$ and define it as  

You can use any base for the logarithm and it won’t make any real difference. If we ask you for numbers, use log base e.  

That’s a lot of fancy words!  

$$
\mathrm{J_{\mathrm{{r}}}(\theta,\theta_{0};\mathcal{D})=\left(\frac{1}{n}\sum_{i=1}^{n}\mathcal{L}_{\mathrm{{nll}}}(\sigma(\theta^{\mathrm{{T}}}x^{(\mathrm{{i}})}+\theta_{0}),y^{(\mathrm{{i}})})\right)+\lambda\left\|\theta\right\|^{2}\;\;.}
$$  

Study Question: Consider the case of linearly separable data. What will the θvalues that optimize this objective be like if $\lambda=0?$ What will they be like if $\uplambda$ is very big? Try to work out an example in one dimension with two data points.  

What role does regularization play for classifiers? This objective function has the same structure as the one we used for regression, Eq. 2.2, where the first term (in parentheses) is the average loss, and the second term is for regularization. Regularization is needed for building classifiers that can generalize well (just as was the case for regression). The parameter $\uplambda$ governs the trade-off between the two terms as illustrated in the following example.  

Suppose we wish to obtain a linear logistic classifier for this one-dimensional dataset:  

![](images/2bdaa5a2e02ad1f8cc7c1350c136c47e1f9daa485df7c443b99f0d226a031c48.jpg)  
x  

Clearly, this can be fit very nicely by a hypothesis ${\sf h}({\sf x})=\upsigma(\uptheta{\sf x})$ , but what is the best value for θ? Evidently, when there is no regularization $(\lambda=0)$ ), the objective function $\operatorname{J}_{\operatorname{lr}}(\theta)$ will approach zero for large values of $\uptheta$ , as shown in the plot on the left, below. However, would the best hypothesis really have an infinite (or very large) value for θ? Such a hypothesis would suggest that the data indicate strong certainty that a sharp transition between ${\mathfrak{y}}=0$ and $\mathfrak{y}=1$ occurs exactly at $x=0$ , despite the actual data having a wide gap around $x=0$ .  

![](images/11725a5225b90ef889bd9f24794e2d3b15a6b61c7e22519ba4f0b26dcfe936a1.jpg)  

Study Question: Be sure this makes sense. When the θvalues are very large, what does the sigmoid curve look like? Why do we say that it has a strong certainty in that case?  

In absence of other beliefs about the solution, we might prefer that our linear logistic classifier not be overly certain about its predictions, and so we might prefer a smaller $\uptheta$ over a large θ. By not being overconfident, we might expect a somewhat smaller θto perform better on future examples drawn from this same distribution. This preference can be realized using a nonzero value of the regularization trade-off parameter, as illustrated in the plot on the right, above, with $\lambda=0.2$ .  

Another nice way of thinking about regularization is that we would like to prevent our hypothesis from being too dependent on the particular training data that we were given: we would like for it to be the case that if the training data were changed slightly, the hypothesis would not change by much.  

To refresh on some vocabulary, we say that in this example, a very large θwould be overfit to the training data.  

# 4.4 Gradient descent for logistic regression  

Now that we have a hypothesis class (LLC) and a loss function (NLL), we need to take some data and find parameters! Sadly, there is no lovely analytical solution like the one we obtained for regression, in Section 2.6.2. Good thing we studied gradient descent! We can perform gradient descent on the $\operatorname{J}_{\operatorname{lr}}$ objective, as we’ll see next. We can also apply stochastic gradient descent to this problem.  

Luckily, $\operatorname{J}_{\operatorname{lr}}$ has enough nice properties that gradient descent and stochastic gradient descent should generally “work”. We’ll soon see some more challenging optimization problems though – in the context of neural networks, in Section 6.7.  

First we need derivatives with respect to both $\uptheta_{0}$ (the scalar component) and θ(the vector component) of $\Theta$ . Explicitly, they are:  

$$
\begin{array}{c}{{\displaystyle\nabla_{\Theta}\boldsymbol{\mathrm{J}}_{\mathrm{lr}}(\Theta,\Theta_{0})=\frac{1}{\boldsymbol{\mathrm{n}}}\sum_{\mathrm{i=1}}^{\boldsymbol{\mathrm{n}}}\left(\boldsymbol{\mathrm{g}}^{(\mathrm{i})}-\boldsymbol{\mathrm{y}}^{(\mathrm{i})}\right)\boldsymbol{\mathrm{x}}^{(\mathrm{i})}+2\lambda\Theta}}\\ {{\displaystyle\frac{\partial\boldsymbol{\mathrm{J}}_{\mathrm{lr}}(\Theta,\Theta_{0})}{\partial\theta_{0}}=\frac{1}{\boldsymbol{\mathrm{n}}}\sum_{\mathrm{i=1}}^{\boldsymbol{\mathrm{n}}}\left(\boldsymbol{\mathrm{g}}^{(\mathrm{i})}-\boldsymbol{\mathrm{y}}^{(\mathrm{i})}\right)\;\;.}}\end{array}
$$  

Some passing familiarity with matrix derivatives is helpful here. A foolproof way of computing them is to compute partial derivative of Jwith respect to each component $\bar{\theta}_{\mathrm{i}}$ of θ.  

Note hat $\nabla_{\theta}{\left\Vert\mathbf{\sigma}_{\mathrm{lr}}\right\Vert}$ will be of shape $\mathrm{d}\times1$ and $\frac{\partial\,{\mathrm{J}_{\mathrm{lr}}}}{\partial\,{\theta_{0}}}$ will be a scalar since we have separated $\uptheta_{0}$ from θhere.  

Study Question: Convince yourself that the dimensions of all these quantities are cor ct, under the assumption that θis $\mathrm{~d~}\times\mathrm{~1~}$ . How does drelate to mas discussed for Θin the previous section?  

$\nabla_{\boldsymbol{\theta}}\left\|\boldsymbol{\theta}\right\|^{2}$ by finding the partial derivatives $(\partial\left\|\dot{\boldsymbol{\theta}}\right\|^{2}/\partial\theta_{1},\ldots,\partial\left\|\boldsymbol{\theta}\right\|^{2}/\partial\theta_{\mathrm{d}})$ ∥∥∥∥. What is the shape of ∇$\nabla_{\theta}\parallel\Theta\|^{2}?$ ∥∥  

Study Question: derivatives $\big(\partial\mathcal{L}_{\mathrm{nll}}\big(\boldsymbol{\sigma}(\boldsymbol{\Theta}^{\mathsf{T}}\boldsymbol{x}+\boldsymbol{\Theta}_{0}),\boldsymbol{\Psi}\big)/\partial\boldsymbol{\theta}_{1},\ldots,\partial\mathcal{L}_{\mathrm{nll}}\big(\boldsymbol{\sigma}(\boldsymbol{\Theta}^{\mathsf{T}}\boldsymbol{x}+\boldsymbol{\Theta}_{0}),\boldsymbol{\Psi}\big)/\partial\boldsymbol{\theta}_{\mathrm{d}}\big)$ Compute $\nabla_{\boldsymbol{\theta}}\mathcal{L}_{\mathrm{nll}}\big(\boldsymbol{\upsigma}(\boldsymbol{\theta}^{\mathsf{T}}\boldsymbol{x}+\boldsymbol{\theta}_{0}),\boldsymbol{\up y}\big)$ by finding the vector of partial .  

Study Question: Use these last two results to verify our derivation above.  

Putting everything together, our gradient descent algorithm for logistic regression becomes:  

LR-G RADIENT -D ESCENT $\left(\theta_{i n i t},\theta_{0i n i t},\upeta,\epsilon\right)$  

1 $\begin{array}{l}{\theta^{(0)}=\theta_{i n i t}}\\ {\theta_{0}^{(0)}=\theta_{0i n i t}}\\ {\mathrm{~t=0~}}\end{array}$   
2   
3   
4 repeat   
5 $\begin{array}{r l}&{\mathbf{t}=\mathbf{t}+1}\\ &{\mathbf{\eta}^{\left(\mathbf{t}\right)}=\Theta^{\left(\mathbf{t}-1\right)}-\eta\left(\frac{1}{n}\sum_{\mathrm{i}=1}^{n}\left(\sigma\left(\Theta^{\left(\mathbf{t}-1\right)^{\mathsf{T}}}\mathbf{x}^{(\mathbf{i})}+\Theta_{0}^{\left(\mathbf{t}-1\right)}\right)-\mathbf{y}^{(\mathbf{i})}\right)\mathbf{x}^{(\mathbf{i})}+2\lambda\Theta^{\left(\mathbf{t}-1\right)}\right)}\\ &{\mathbf{\eta}_{0}^{\left(\mathbf{t}\right)}=\Theta_{0}^{\left(\mathbf{t}-1\right)}-\eta\left(\frac{1}{n}\sum_{\mathrm{i}=1}^{n}\left(\sigma\left(\Theta^{\left(\mathbf{t}-1\right)^{\mathsf{T}}}\mathbf{x}^{(\mathbf{i})}+\Theta_{0}^{\left(\mathbf{t}-1\right)}\right)-\mathbf{y}^{(\mathbf{i})}\right)\right)}\\ &{\mathbf{\mathbf{\eta}}\mathbf{\mathbf{t}}\mathbf{i}\left|\left|\mathrm{J_{\mathrm{r}}}(\Theta^{\left(\mathbf{t}\right)},\Theta_{0}^{\left(\mathbf{t}\right)})-\mathrm{J_{\mathrm{r}}}(\Theta^{\left(\mathbf{t}-1\right)},\Theta_{0}^{\left(\mathbf{t}-1\right)})\right|<\epsilon}\\ &{\mathbf{\mathbf{t}}\mathbf{u}\mathbf{r}\Theta^{\left(\mathbf{t}\right)},\Theta_{0}^{\left(\mathbf{t}\right)}}\end{array}$   
9 return  

Logistic regression, implemented using batch or stochastic gradient descent, is a useful and fundamental machine learning technique. We will also see later that it corresponds to a one-layer neural network with a sigmoidal activation function, and so is an important step toward understanding neural networks.  

# 4.4.1 Convexity of the NLL Loss Function  

Much like the squared-error loss function that we saw for linear regression, the NLL loss function for linear logistic regression is a convex function. This means that running gradient descent with a reasonable set of hyperparameters will converge arbitrarily close to the minimum of the objective function.  

We will use the following facts to demonstrate that the NLL loss function is a convex function:  

• if the derivative of a function of a scalar argument is monotonically increasing, then it is a convex function,   
• the sum of convex functions is also convex,   
• a convex function of an affine function is a convex function.  

Let $z=\boldsymbol{\Theta}^{\top}\boldsymbol{\mathrm{x}}+\boldsymbol{\theta}_{0};\,z$ is an affine function of θand $\uptheta_{0}$ . It therefore suffices to show that the functions ${\mathfrak{f}}_{1}(z)=-\log(\sigma(z))$ and $\mathsf{f}_{2}(z)=-\log(1-\upsigma(z))$ are convex with respect to $z$ .  

First, we can see that since,  

$$
\begin{array}{l}{\displaystyle\frac{\mathrm{d}}{\mathrm{d}z}\mathbf{f}_{1}(z)=\frac{\mathrm{d}}{\mathrm{d}z}\left[-\log(1/(1+\exp(-z)))\right],}\\ {\displaystyle\qquad\qquad=\frac{\mathrm{d}}{\mathrm{d}z}\left[\log(1+\exp(-z))\right],}\\ {\displaystyle\qquad=-\exp(-z)/(1+\exp(-z)),}\\ {\displaystyle\qquad=-1+\sigma(z),}\end{array}
$$  

the derivative of the function $\mathsf{f}_{1}(z)$ is a monotonically increasing function and therefore ${\boldsymbol{\mathsf{f}}}_{1}$ is a convex function.  

Second, we can see that since,  

$$
\begin{array}{l}{\displaystyle\frac{\mathrm{d}}{\mathrm{d}z}\mathbf{f}_{2}(z)=\displaystyle\frac{\mathrm{d}}{\mathrm{d}z}\left[-\log(\exp(-z)/(1+\exp(-z)))\right],}\\ {\displaystyle\qquad\qquad=\frac{\mathrm{d}}{\mathrm{d}z}\left[\log(1+\exp(-z))+z\right],}\\ {\displaystyle\qquad=\sigma(z),}\end{array}
$$  

the derivative of the function $f_{2}(z)$ is also monotonically increasing and therefore $\boldsymbol{\mathsf{f}}_{2}$ is a convex function.  

# 4.5 Handling multiple classes  

So far, we have focused on the binary classification case, with only two possible classes. But what can we do if we have multiple possible classes (e.g., we want to predict the genre of a movie)? There are two basic strategies:  

• Train multiple binary classifiers using different subsets of our data and combine their outputs to make a class prediction. • Directly train a multi-class classifier using a hypothesis class that is a generalization of logistic regression, using a one-hot output encoding and NLL loss.  

The method based on NLL is in wider use, especially in the context of neural networks, and is explored here. In the following, we will assume that we have a data set $\mathcal{D}$ in which the inputs $\boldsymbol{\mathbf{\ell}}_{\boldsymbol{x}}^{(\mathrm{i})}\in\mathbb{R}^{\mathrm{d}}$ but the outputs $\bar{\mathbf{y}^{(i)}}$ are drawn from a set of Kclasses $\{\mathsf{c}_{1},\dotsc,\mathsf{c}_{\mathsf{K}}\}$ . Next, we extend the idea of NLL directly to multi-class classification with Kclasses, where the training label is represented with what is called a one-hot vector $\mathbf{y}=\left[\mathop{\mathbf{y}}_{1},\dots,\mathop{\mathbf{y}}_{\sf}{\kappa}\right]^{\sf T},$ '', where $\mathfrak{y}_{\mathsf{k}}\,=\,1$ if the example is of class $\boldsymbol{\mathrm{k}}$ and $\mathfrak{y}_{\mathsf{k}}\,=\,0$ otherwise. Now, we have a problem of mapping an input $\bar{\mathbf{x}^{(\mathfrak{i})}}$ that is in $\mathbb{R}^{\mathrm{d}}$ into a K-dimensional output. Furthermore, we would like this output to be interpretable as a discrete probability distribution over the possible classes, which means the elements of the output vector have to be non-negative (greater than or equal to 0) and sum to 1.  

We will do this in two steps. First, we will map our input $x^{(\mathrm{i})}$ into a vector value $\boldsymbol{z}^{(\mathrm{i})}\in\mathbb{R}^{\mathsf{K}}$ by letting θbe a whole ${\tt d}\times{\tt K}$ matrix of parameters, and $\uptheta_{0}$ be a $\kappa\times1$ vector, so that  

$$
z={\boldsymbol{\theta}}^{\mathsf{T}}{\boldsymbol{\times}}+{\boldsymbol{\theta}}_{0}\;\;.
$$  

Next, we have to extend our use of the sigmoid function to the multi-dimensional softmax Let’s check dimensions! function, that takes a whole vector $z\in\mathbb{R}^{\mathsf{K}}$ and generates $\uptheta^{\top}$ is $\mathsf{K}\!\times\!\mathsf{d}$ $x$ is ${\tt d}\!\times\!1$ ,  

$$
\begin{array}{r}{\mathbf{g}=s o f t m a x(z)=\left[\begin{array}{c}{\exp(z_{1})/\sum_{\mathrm{i}}\exp(z_{\mathrm{i}})}\\ {\vdots}\\ {\exp(z_{\mathrm{K}})/\sum_{\mathrm{i}}\exp(z_{\mathrm{i}})\rule{0ex}{5ex}}\end{array}\right]\ \,.}\end{array}
$$  

which can be interpreted as a probability distribution over Kitems. To make the final prediction of the class label, we can then look at $9.$ , find the most likely probability over these Kentries in g, (i.e. find the largest entry in ${\mathfrak{g}},$ ) and return the corresponding index as the “one-hot” element of 1 in our prediction.  

Study Question: Convince yourself that the vector of $\mathfrak{g}$ values will be non-negative and sum to 1.  

Putting these steps together, our hypotheses will be  

$$
\mathrm{h}(\mathrm{x};\theta,\theta_{0})=s o f t m a x(\theta^{\top}\mathrm{x}+\theta_{0})\;\;.
$$  

Now, we retain the goal of maximizing the probability that our hypothesis assigns to the correct output $y_{k}$ for each input $x$ . We can write this probability, letting gstand for our “guess”, $\ln(x)$ , for a single example $(x,y)$ as $\Pi_{\mathbf{k}=1}^{\mathbf{K}}\,\mathfrak{g}_{\mathbf{k}}^{\Psi\mathbf{k}}$ .  

Study Question: How many elements that are not equal to 1 will there be in this product?  

The negative log of the probability that we are making a correct guess is, then, for onehot vector $\boldsymbol{\mathfrak{y}}$ and probability distribution vector $\mathfrak{g}$ ,  

$$
\mathcal{L}_{\mathrm{nllm}}(\mathbf{g},\mathbf{y})=-\sum_{\mathbf{k}=1}^{\mathbf{K}}\mathbf{y}_{\mathbf{k}}\cdot\log(\mathbf{g}_{\mathbf{k}})\;\;.
$$  

We’ll call this NLLM for negative log likelihood multiclass. It is also worth noting that the NLLM loss function is also convex; however, we will omit the proof.  

Study Question: Be sure you see that is $\mathcal{L}_{\mathrm{nllm}}$ is minimized when the guess assigns high probability to the true class.  

Study Question: Show that $\mathcal{L}_{\mathrm{nllm}}$ for $\mathsf K=2$ is the same as $\mathcal{L}_{\mathrm{nll}}$ .  

# 4.6 Prediction accuracy and validation  

In order to formulate classification with a smooth objective function that we can optimize robustly using gradient descent, we changed the output from discrete classes to probability values and the loss function from 0-1 loss to NLL. However, when time comes to actually make a prediction we usually have to make a hard choice: buy stock in Acme or not? And, we get rewarded if we guessed right, independent of how sure or not we were when we made the guess.  

The performance of a classifier is often characterized by its accuracy , which is the percentage of a data set that it predicts correctly in the case of 0-1 loss. We can see that accuracy of hypothesis $\mathtt{h}$ on data $\mathcal{D}$ is the fraction of the data set that does not incur any loss:  

$$
\mathsf{A}(\mathbf{h};\mathbb{D})=1-\frac{1}{\mathsf{n}}\sum_{\mathrm{i}=1}^{\mathsf{n}}\mathcal{L}_{01}(\mathbf{g}^{(\mathrm{i})},\mathbf{y}^{(\mathrm{i})})\;\;,
$$  

where ${\mathfrak{g}}^{({\mathrm{i}})}$ is the final guess for one class or the other that we make from $\mathsf{h}(\mathsf{x}^{(\mathrm{i})})$ , e.g., after thresholding. It’s noteworthy here that we use a different loss function for optimization than for evaluation. This is a compromise we make for computational ease and efficiency.  