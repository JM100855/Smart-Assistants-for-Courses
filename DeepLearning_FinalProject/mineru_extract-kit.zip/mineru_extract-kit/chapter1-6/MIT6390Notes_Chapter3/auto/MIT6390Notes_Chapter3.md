Regression  

Regression is an important machine-learning problem that provides a good starting point for diving deeply into the field.  

“Regression,” in common parlance, means moving backwards. But this is forward progress!  

# 2.1 Problem formulation  

A hypothesis $\boldsymbol{\mathrm{h}}$ is employed as a model for solving the regression problem, in that it maps inputs $x$ to outputs $\mathfrak{y}.$ ,  

$$
x\rightarrow\boxed{\mathbf{h}}\rightarrow\mathbf{y}\;\;,
$$  

where $\boldsymbol{x}\ \in\ \mathbb{R}^{\mathbf{d}}$ (i.e., a length dcolumn vector of real numbers), and $\textsf{y}\in\mathrm{~\mathbb{R}~}$ (i.e., a real number). Real life rarely gives us vectors of real numbers; the $x$ we really want to take as input is usually something like a song, image, or person. In that case, we’ll have to define a function $\varphi(x)$ , whose range is $\mathbb{R}^{\mathrm{d}}$ , where $\boldsymbol{\varphi}$ represents features of $x,$ , like a person’s height or the amount of bass in a song, and then let the $\mathsf{h}:\varphi(\mathsf{x})\to\mathbb{R}.$ much of the following, we’ll omit explicit mention of $\boldsymbol{\varphi}$ and assume that the $x^{(\mathrm{i})}$ are in $\mathbb{R}^{\mathrm{d}}$ , but you should always have in mind that some additional process was almost surely required to go from the actual input examples to their feature representation, and we’ll talk a lot more about features later in the course.  

Regression is a supervised learning problem, in which we are given a training dataset of the form  

$$
\mathcal{D}_{\mathfrak{n}}=\left\{\left(x^{(1)},\mathfrak{y}^{(1)}\right),\ldots,\left(x^{(\mathfrak{n})},\mathfrak{y}^{(\mathfrak{n})}\right)\right\}\;\;,
$$  

which gives examples of input values $x^{(\mathrm{i})}$ and the output values $\mathfrak{y}^{(\mathrm{i})}$ that should be associated with them. Because $\mathfrak{y}$ values are real-valued, our hypotheses will have the form  

$$
\mathsf{h}:\mathbb{R}^{\mathbf{d}}\to\mathbb{R}\ \mathrm{~.~}
$$  

This is a good framework when we want to predict a numerical quantity, like height, stock value, etc., rather than to divide the inputs into discrete categories.  

What makes a hypothesis useful? That it works well on new data; that is, that it makes good predictions on examples it hasn’t seen. But we don’t know exactly what data this hypothesis might be tested on when we use it in the real world. So, we have to assume a connection between the training data and testing data – typically, the assumption is that  

My favorite analogy is to problem sets. We evaluate a student’s ability to generalize by putting questions on the exam that were not on the homework (training set).  

they (the training and testing data) are drawn independently from the same probability distribution.  

To make this discussion more concrete, we have to provide a loss function , to say how unhappy we are when we guess an output $9$ given an input $x$ for which the desired output was a .  

Given a training set $\mathcal{D}_{\mathfrak{n}}$ and a hypothesis $\mathtt{h}$ with parameters $\Theta_{.}$ , we can define the training error of $\mathtt{h}$ to be the average loss on the training data:  

$$
\displaystyle\xi_{\ n}(\mathbf{h};\Theta)=\frac{1}{\mathfrak{n}}\sum_{\mathfrak{i}=1}^{\mathfrak{n}}\mathcal{L}(\mathbf{h}(\mathbf{x}^{(\mathfrak{i})};\Theta),\mathfrak{y}^{(\mathfrak{i})})~~,
$$  

The training error of $\boldsymbol{\mathrm{h}}$ gives us some idea of how well it characterizes the relationship between $x$ and $\mathfrak{y}$ values in our data, but it isn’t the quantity that we most care about. What we most care about is test error :  

$$
\mathcal{E}(\mathbf{h})=\frac{1}{\mathfrak{n^{\prime}}}\sum_{\mathfrak{i}=\mathfrak{n}+1}^{\mathfrak{n}+\mathfrak{n^{\prime}}}\mathcal{L}(\mathfrak{h}(\mathfrak{x}^{(\mathfrak{i})}),\mathfrak{y}^{(\mathfrak{i})})
$$  

on $n^{\prime}$ new examples that were not used in the process of finding the hypothesis.  

For now, we will try to find a hypothesis with small training error (later, with some added criteria) and try to make some design choices so that it generalizes well to new data, meaning that it also has a small test error .  

# 2.2 Regression as an optimization problem  

Given data, a loss function, and a hypothesis class, we need a method for finding a good hypothesis in the class. One of the most general ways to approach this problem is by framing the machine learning problem as an optimization problem. One reason for taking this approach is that there is a rich area of math and algorithms studying and developing efficient methods for solving optimization problems, and lots of very good software implementations of these methods. So, if we can turn our problem into one of these problems, then there will be a lot of work already done for us!  

We begin by writing down an objective function $\displaystyle\mathrm{J}(\Theta)$ , where $\Theta$ stands for all the parameters in our model (i.e., all possible choices over parameters). We often write $\operatorname{J}(\Theta;\mathcal{D})$ to make clear the dependence on the data $\mathcal{D}$ .  

It might be worthwhile to stare at the two errors and think about what’s the difference. For example, notice how $\Theta$ is no long a variable in the testing error? this is because in evaluating the testing error, the parameters will have been "picked"/"fixed" already.  

The objective function describes how we feel about possible hypotheses $\Theta$ : we will generally look for values for parameters $\Theta$ that minimize the objective function:  

$$
\Theta^{*}=\arg\operatorname*{min}_{\Theta}\left[\Theta\right]\;.
$$  

A very common form for a machine-learning objective is  

Don’t be too perturbed by the semicolon where you expected to see a comma! It’s a math way of saying that we are mostly interested in this as a function of the arguments before the “;”, but we should remember that there’s a dependence on the stuff after it, as well.  

$$
\mathsf{J}(\Theta)=\left(\frac{1}{\mathsf{n}}\sum_{\mathrm{i}=1}^{\mathsf{n}}\underbrace{\mathcal{L}(\mathsf{h}(x^{(\mathrm{i})};\Theta),\mathsf{y}^{(\mathrm{i})})}_{\mathrm{loss}}\right)+\underbrace{\lambda}_{\mathrm{non-negative\;constant}}\mathsf{R}(\Theta).
$$  

The loss tells us how unhappy we are about the prediction ${\mathsf{h}}({\mathsf{x}}^{(\mathrm{i})};\Theta)$ that $\Theta$ makes for $(\mathbf{\boldsymbol{x}}^{(\mathrm{i})},\mathbf{\boldsymbol{y}}^{(\mathrm{i})})$ ). Minimizing this loss makes the prediction better. The regularizer is an additional term that encourages the prediction to remain general, and the constant $\lambda$ adjusts the balance between reproducing seen examples, and being able to generalize to unseen examples. We will return to discuss this balance, and more about the idea of regularization, in Section 2.6.  

You can think about $\Theta^{*}$ here as “the theta that minimizes $\mathrm{J^{\prime\prime}}$ :arg $;\mathbf{min}_{\mathrm{x}}\;\mathbf{f}(\mathrm{x})$ means the value of $x$ for which $\mathsf{f}(\mathsf{x})$ is the smallest. Sometimes we write arg $\scriptstyle\mathbf{min}_{\mathbf{x}\in{\mathcal{X}}}$ $\mathsf{f}(\mathsf{x})$ when we want to explicitly specify the set $\mathcal{X}$ of values of $x$ over which we want to minimize.  

Last Updated: 05/06/24 18:25:27  

# 2.3 Linear regression  

To make this discussion more concrete, we have to provide a hypothesis class and a loss function.  

We will begin by picking a class of hypotheses $\mathcal{H}$ that we think might provide a good set of possible models of the relationship between $x$ and $\mathfrak{y}$ in our data. We will start with a very simple class of linear hypotheses for regression. It is both simple to study and very powerful, and will serve as the basis for many other important techniques (even neural networks!).  

In linear regression, the set $\mathcal{H}$ of hypotheses has the form  

$$
\mathrm{h}(\mathrm{x};\theta,\theta_{0})=\Theta^{\mathsf{T}}\mathrm{x}+\theta_{0}\,\mathrm{~,~}
$$  

with model parameters $\Theta=\left(\theta,\theta_{0}\right)$ . In one dimension ( $[\mathrm{d}=1]$ ) this has the same familiar slope-intercept form as $y=\operatorname*{mx}+6.$ ; in higher dimensions, this model describes the so-called hyperplanes.  

We define a loss function to describe how to evaluate the quality of the predictions our hypothesis is making, when compared to the “target” $\boldsymbol{\mathfrak{y}}$ values in the data set. The choice of loss function is part of modeling your domain. In the absence of additional information about a regression problem, we typically use squared loss :  

$$
\begin{array}{r}{\mathcal{L}(\mathbf{\boldsymbol{g}},\mathbf{\boldsymbol{a}})=(\mathbf{\boldsymbol{g}}-\mathbf{\boldsymbol{a}})^{2}\ \,}\end{array}
$$  

where ${\mathfrak{g}}={\mathfrak{h}}({\mathfrak{x}})$ is our "guess" from the hypothesis, and a is the "actual" observation (in other words, here a is being used equivalently as $\mathfrak{y}$ ). With this choice of squared loss, the average loss as generally defined in 2.1 will become the so-called mean squared error (MSE), which we’ll study closely very soon.  

The squared loss penalizes guesses that are too high the same amount as it penalizes guesses that are too low, and has a good mathematical justification in the case that your data are generated from an underlying linear hypothesis with the so-called Gaussiandistributed noise added to the yvalues. But there are applications in which other losses would be better, and much of the framework we discuss can be applied to different loss functions, although this one has a form that also makes it particularly computationally convenient.  

Our objective in linear regression will be to find a hyperplane that goes as close as possible, on average, to all of our training data.  

Applying the general optimization framework to the linear regression hypothesis class of Eq. 2.3 with squared loss and no regularization, our objective is to find values for $\Theta=$ $\left(\theta,\theta_{0}\right)$ that minimize the MSE:  

We won’t get into the details of Gaussian distribution in our class; but it’s one of the most important distributions and well-worth studying closely at some point. One obvious fact about Gaussian is that it’s symmetric; this is in fact one of the reasons squared loss works well under Gaussian settings, as the loss is also symmetric.  

$$
\small\mathrm{J}(\boldsymbol{\theta},\boldsymbol{\theta}_{0})=\frac{1}{n}\sum_{\mathrm{i}=1}^{\mathrm{n}}\left(\boldsymbol{\theta}^{\mathrm{T}}\boldsymbol{x}^{(\mathrm{i})}+\boldsymbol{\theta}_{0}-\boldsymbol{\Psi}^{(\mathrm{i})}\right)^{2}\;\;,
$$  

resulting in the solution:  

$$
\Theta^{*},\Theta_{0}^{*}=\arg\operatorname*{min}_{\theta,\theta_{0}}\left J(\theta,\theta_{0})\right.\ .
$$  

For one-dimensional data $(\mathrm{d}\,=\,1)$ ), this becomes the familiar problem of fitting a line to data. For $\textnormal{d}>\textnormal{1},$ this hypothesis may be visualized as a ${\mathrm d}$ -dimensional hyperplane embedded in a $(\mathsf{d}+1)$ -dimensional space (that consists of the input dimension and the ydimension). For example, in the left plot below, we can see data points with labels yand input dimensions $x_{1}$ and $\boldsymbol{x}_{2}$ . In the right plot below, we see the result of fitting these points with a two-dimensional plane that resides in three dimensions. We interpret the plane as representing a function that provides a $\boldsymbol{\mathfrak{y}}$ value for any input $\left(x_{1},x_{2}\right)$ .  

![](images/35a3691b981dcae371ff865518196e53ebdcc1bd8fba5a083098f4d6b3776000.jpg)  

A richer class of hypotheses can be obtained by performing a non-linear feature transformation before doing the regression, as we will later see (in Chapter 5), but it will still end up that we have to solve a linear regression problem.  

# 2.4 A gloriously simple linear regression algorithm  

Okay! Given the objective in Eq. 2.4, how can we find good values of θand $\uptheta_{0}$ ? We’ll study several general-purpose, efficient, interesting algorithms. But before we do that, let’s start with the simplest one we can think of: guess a whole bunch ( k) of different values of $\uptheta$ and $\theta_{0},$ see which one has the smallest error on the training set, and return it.  

RANDOM -R EGRESSION $\left({\mathcal{D}},{\mathsf{k}}\right)$  

1 For i in 1 . . . k: Randomly generate hypothesis ${\Theta}^{\mathrm{(i)}}$ ,$\Theta_{0}^{\mathrm{(i)}}$   
2 Let $\mathrm{i\,=\,\!\arg\operatorname*{min}_{i}\,\!\int(\boldsymbol{\theta}^{(i)},\boldsymbol{\theta}_{0}^{(i)};\mathcal{D})}$   
3 Return $\theta^{(\mathrm{i})},\theta_{0}^{(\mathrm{i})}$  

This seems kind of silly, but it’s a learning algorithm, and it’s not completely useless.  

Study Question: If your data set has ndata points, and the dimension of the xvalues is ${\mathrm{d}},$ what is the size of an individual θ(i )?  

Study Question: How do you think increasing the number of guesses kwill change the training error of the resulting hypothesis?  

# 2.5 Analytical solution: ordinary least squares  

One very interesting aspect of the problem of finding a linear hypothesis that minimizes mean squared error is that we can find a closed-form formula for the answer! This general problem is often called the ordinary least squares (OLS )  

Everything is easier to deal with if we assume that all of the the $x^{(\mathrm{i})}$ have been augmented with an extra input dimension (feature) that always has value 1, so that they are in ${\tt d}+1$ dimensions, and rather than having an explicit $\theta_{0},$ we let it be the last element of our θvector, so that we have, simply,  

$$
\begin{array}{r}{\mathfrak{y}=\mathfrak{theta}^{\mathsf{T}}\mathfrak{x}\ .}\end{array}
$$  

What does “closed form” mean? Generally, that it involves direct evaluation of a mathematical expression using a fixed number of “typical” operations (like arithmetic operations, trig functions, powers, etc.). So equation 2.5 is not in closed form, because it’s not at all clear what operations one needs to perform to find the solution.  

In this case, the objective becomes  

$$
{\boldsymbol{\mathrm{J}}}(\theta)={\frac{1}{\mathsf{n}}}\sum_{\mathrm{i}=1}^{\mathsf{n}}\left(\theta^{\mathsf{T}}x^{(\mathrm{i})}-\mathsf{y}^{(\mathrm{i})}\right)^{2}\ .
$$  

Study Question: Stop and prove to yourself that adding that extra feature with value 1 to every input vector and getting rid of the $\uptheta_{0}$ parameter is equivalent to our original model.  

We approach this just like a minimization problem from calculus homework: take the derivative of Jwith respect to θ, set it to zero, and solve for θ. There are additional steps required, to check that the resulting θis a minimum (rather than a maximum or an inflection point) but we won’t work through that here. It is possible to approach this problem by:  

• Constructing a set of $\boldsymbol{\mathrm{k}}$ equations of the form ∂J $'\partial\theta_{\sf k}=0,$ , and • Solving the system for values of $\uptheta_{\mathrm{k}}$ .  

We will use dhere for the total number of features in each $x^{(\mathrm{i})}$ , including the added 1.  

That works just fine. To get practice for applying techniques like this to more complex problems, we will work through a more compact (and cool!) matrix view. Along the way, it will be helpful to collect all of the derivatives in one vector. In particular, the gradient of Jwith respect to θis following column vector of length d:  

$$
\nabla_{\Theta}\boldsymbol{\mathrm{J}}=\left[\!\!\begin{array}{c}{\hat{\boldsymbol{0}}\boldsymbol{\mathrm{J}}/\hat{\boldsymbol{0}}\theta_{1}}\\ {\vdots}\\ {\hat{\boldsymbol{0}}\boldsymbol{\mathrm{J}}/\hat{\boldsymbol{0}}\theta_{\mathrm{d}}}\end{array}\!\!\right].
$$  

Study Question: Work through the next steps and check your answer against ours below.  

We can think of our training data in terms of matrices $x$ and Y, where each column of Xis an example, and each “column” of Yis the corresponding target output value:  

$$
{\boldsymbol{\mathsf{X}}}={\left[\begin{array}{c c c c}{\mathsf{x}_{1}^{(1)}}&{\ldots}&{\mathsf{x}_{1}^{(\mathsf{n})}}\\ {\vdots}&{\ddots}&{\vdots}\\ {\mathsf{x}_{\mathrm{d}}^{(1)}}&{\ldots}&{\mathsf{x}_{\mathrm{d}}^{(\mathsf{n})}}\end{array}\right]}\quad{\mathsf{Y}}={\left[\mathbf{y}^{(1)}\quad\ldots\quad\mathbf{y}^{(\mathsf{n})}\right]}\enspace.
$$  

Study Question: What are the dimensions of Xand Y?  

In most textbooks, they think of an individual example $x^{(\mathrm{i})}$ as a row, rather than a column. So that we get an answer that will be recognizable to you, we are going to define a new matrix and vector, $\tilde{X}$ and $\tilde{\mathsf{Y}}_{,}$ , which are just transposes of our Xand Y, and then work with them:  

$$
\tilde{{\boldsymbol{X}}}={\boldsymbol{X}}^{\mathsf{T}}=\left[\begin{array}{c c c}{\mathsf{x}_{1}^{(1)}}&{\ldots}&{\mathsf{x}_{\mathrm{d}}^{(1)}}\\ {\vdots}&{\ddots}&{\vdots}\\ {\mathsf{x}_{1}^{(\mathsf{n})}}&{\ldots}&{\mathsf{x}_{\mathrm{d}}^{(\mathsf{n})}}\end{array}\right]\;\;\tilde{{\mathsf{Y}}}={\mathsf{Y}}^{\mathsf{T}}=\left[\begin{array}{c}{\mathsf{y}^{(1)}}\\ {\vdots}\\ {\mathsf{y}^{(\mathsf{n})}}\end{array}\right]\;\;.
$$  

Study Question: What are the dimensions of Xand Y?  

Now we can write  

$$
\mathrm{J}(\theta)=\frac{1}{\mathrm{n}}\,(\tilde{\Sigma}\theta-\tilde{\Upsilon})^{\mathrm{T}}\underbrace{(\tilde{X}\theta-\tilde{\Upsilon})}_{\mathrm{n}\,\times1}=\frac{1}{\mathrm{n}}\sum_{\mathrm{i}=1}^{\mathrm{n}}\left(\left(\sum_{\mathrm{j}=1}^{\mathrm{d}}\tilde{X}_{\mathrm{ij}}\theta_{\mathrm{j}}\right)-\tilde{\Upsilon}_{\mathrm{i}}\right)^{2}
$$  

and using facts about matrix/vector calculus, we get  

$$
\nabla_{\boldsymbol{\theta}}\boldsymbol{\mathrm{J}}=\frac{2}{\ n}\underbrace{\tilde{\boldsymbol{\chi}}^{\intercal}}_{\boldsymbol{\mathrm{d}}\times\boldsymbol{\mathrm{n}}}\underbrace{(\tilde{\boldsymbol{\chi}}\boldsymbol{\theta}-\tilde{\boldsymbol{\Upsilon}})}_{\boldsymbol{\mathrm{n}}\times\boldsymbol{\mathrm{1}}}\ \ .
$$  

See Appendix A for a nice way to think about finding this derivative. Setting $\nabla_{\theta}$ Jto 0 and solving, we get:  

$$
\begin{array}{l}{\displaystyle\frac{2}{\mathsf{n}}\tilde{\mathsf{X}}^{\mathsf{T}}(\tilde{\mathsf{X}}\Theta-\tilde{\mathsf{Y}})=0}\\ {\displaystyle\tilde{\mathsf{X}}^{\mathsf{T}}\tilde{\mathsf{X}}\Theta-\tilde{\mathsf{X}}^{\mathsf{T}}\tilde{\mathsf{Y}}=0}\\ {\displaystyle\tilde{\mathsf{X}}^{\mathsf{T}}\tilde{\mathsf{X}}\Theta=\tilde{\mathsf{X}}^{\mathsf{T}}\tilde{\mathsf{Y}}}\\ {\displaystyle\Theta=(\tilde{\mathsf{X}}^{\mathsf{T}}\tilde{\mathsf{X}})^{-1}\tilde{\mathsf{X}}^{\mathsf{T}}\tilde{\mathsf{Y}}}\end{array}
$$  

And the dimensions work out!  

$$
\theta=\underbrace{\left(\tilde{X}^{\mathsf{T}}\tilde{X}\right)^{-1}}_{\mathrm{d}\times\mathrm{d}}\underbrace{\tilde{X}^{\mathsf{T}}}_{\mathrm{d}\times\mathrm{n}}\underbrace{\tilde{Y}}_{\mathrm{n}\times1}
$$  

So, given our data, we can directly compute the linear regression that minimizes mean squared error. That’s pretty awesome!  

# 2.6 Regularization  

The objective function of Eq. 2.2 balances (training-data) memorization, induced by the loss term, with generalization, induced by the regularization term. Here, we address the need for regularization specifically for linear regression, and show how this can be realized using one popular regularization technique called ridge regression .  

# 2.6.1 Regularization and linear regression  

If all we cared about was finding a hypothesis with small loss on the training data, we would have no need for regularization, and could simply omit the second term in the objective. But remember that our ultimate goal is to perform well on input values that we haven’t trained on! It may seem that this is an impossible task, but humans and machinelearning methods do this successfully all the time. What allows generalization to new input values is a belief that there is an underlying regularity that governs both the training and testing data. One way to describe an assumption about such a regularity is by choosing a limited class of possible hypotheses. Another way to do this is to provide smoother guidance, saying that, within a hypothesis class, we prefer some hypotheses to others. The regularizer articulates this preference and the constant $\uplambda$ says how much we are willing to trade off loss on the training data versus preference over hypotheses.  

For example, consider what happens when ${\mathrm{d}}\,=\,2,$ and $x_{2}$ is highly correlated with $x_{1},$ meaning that the data look like a line, as shown in the left panel of the figure below. Thus, there isn’t a unique best hyperplane . Such correlations happen often in real-life data, because of underlying common causes; for example, across a population, the height of people may depend on both age and amount of food intake in the same way. This is especially the case when there are many feature dimensions used in the regression. Mathematically, this leads to $\tilde{X}^{\top}\tilde{X}$ close to singularity, such that $(\tilde{X}^{\top}\tilde{X})^{-1}$ is undefined or has huge values, resulting in unstable models (see the middle panel of figure and note the range of the $\mathfrak{y}$ values—the slope is huge!):  

![](images/4cf8c187ed8e106195ac401a7dad7d14a70bcecc6aa5c7091dc029d7f6423969.jpg)  

A common strategy for specifying a regularizer is to use the form  

$$
\mathsf{R}(\Theta)=\left\lVert\Theta-\Theta_{p r i o r}\right\rVert^{2}
$$  

when we have some idea in advance that $\Theta$ ought to be near some value $\Theta_{p r i o r}$ .Learn about Bayesian Here, the notion of distance is quantified by squaring the $\boldsymbol{\mathrm{l}}_{2}$ norm of the parameter methods in machine vector: for any ${\mathrm d}{}.$ -dimensional vector $\upnu\in\mathbb{R}^{\mathrm{d}}$ , the $\boldsymbol{\mathrm{l}}_{2}$ norm of $\nu$ is defined as, learning to see the theory behind this and cool  

$$
\|\mathbf{\boldsymbol{v}}\|=\sqrt{\sum_{\mathrm{i}=1}^{\mathrm{d}}|\nu_{\mathrm{i}}|^{2}}\,\mathrm{~.~}
$$  

In the absence of such knowledge a default is to regularize toward zero :  

$$
{\sf R}(\Theta)=\left\|\Theta\right\|^{2}\;\;.
$$  

When this is done in the example depicted above, the regression model becomes stable, producing the result shown in the right-hand panel in the figure. Now the slope is much more sensible.  

# 2.6.2 Ridge regression  

There are some kinds of trouble we can get into in regression problems. What if $\left(\tilde{X}^{\top}\tilde{X}\right)$ is not invertible?  

Study Question: Consider, for example, a situation where the data-set is just the same point repeated twice: $\mathsf{x}^{(1)}\;=\;\mathsf{x}^{\bar{(2)}}\;=\;[1\;\;2]^{\mathsf{T}}$ . What is $\tilde{X}$ in this case? What is ${\tilde{X}}^{\top}{\tilde{X}}^{\prime}$ What is $(\tilde{X}^{\top}\tilde{X})^{-1}?$  

Another kind of problem is overfitting : we have formulated an objective that is just about fitting the data as well as possible, but we might also want to regularize to keep the hypothesis from getting too attached to the data.  

We address both the problem of not being able to invert $(\tilde{X}^{\top}\tilde{X})^{-1}$ and the problem of overfitting using a mechanism called ridge regression .We add a regularization term $\lVert\boldsymbol{\theta}\rVert^{2}$ to the OLS objective, with a non-negative scalar value λto control the tradeoff between the training error and the regularization term.  

# 2.7.1 Evaluating hypotheses  

The performance of a given hypothesis hmay be evaluated by measuring test error on data that was not used to train it. Given a training set $\underline{{\mathcal{D}_{\mathbf{n},\epsilon}}}$ a regression hypothesis $\underline{{\mathrm{h}}},$ and if we choose squared loss, we can define the OLS training error of $\boldsymbol{\mathrm{h}}$ to be the mean square error between its predictions and the expected outputs:  

$$
\displaystyle\mathcal{E}_{\mathfrak{n}}({\bf h})=\frac{1}{\mathfrak{n}}\sum_{\mathfrak{i}=1}^{\mathfrak{n}}\left[\mathtt{h}(\boldsymbol{\mathfrak{x}}^{(\mathfrak{i})})-\boldsymbol{\mathfrak{y}}^{(\mathfrak{i})}\right]^{2}\ \,.
$$  

Test error captures the performance of $\mathtt{h}$ on unseen data, and is the mean square error on the test set, with a nearly identical expression as that above, differing only in the range of index i :  

$$
\mathcal{E}(\mathbf{h})=\frac{1}{{\mathfrak{n}}^{\prime}}\sum_{\mathrm{i}={\mathfrak{n}}+1}^{{\mathfrak{n}}+{\mathfrak{n}}^{\prime}}\left[{\mathfrak{h}}({\mathfrak{x}}^{(\mathrm{i})})-{\mathfrak{y}}^{(\mathrm{i})}\right]^{2}
$$  

on $\mathfrak{n^{\prime}}$ new examples that were not used in the process of constructing h.  

In machine learning in general, not just regression, it is useful to distinguish two ways in which a hypothesis $\mathsf{h}\in\mathcal{H}$ might contribute to test error. Two are:  

Structural error : This is error that arises because there is no hypothesis $\mathtt{h}\in\mathcal{H}$ that will perform well on the data, for example because the data was really generated by a sine wave but we are trying to fit it with a line.  

Estimation error : This is error that arises because we do not have enough data (or the data are in some way unhelpful) to allow us to choose a good $\mathsf{h}\in\mathcal{H},$ or because we didn’t solve the optimization problem well enough to find the best hgiven the data that we had.  

When we increase $\lambda,$ we tend to increase structural error but decrease estimation error, and vice versa.  

# 2.7.2 Evaluating learning algorithms  

Note that this section is relevant to learning algorithms generally—we are just introducing the topic here since we now have an algorithm that can be evaluated!  

A learning algorithm is a procedure that takes a data set $\mathcal{D}_{\mathfrak{n}}$ as input and returns an hypothesis hfrom a hypothesis class $\mathcal{H};$ it looks like  

$$
\mathfrak{D}_{\mathfrak{n}}\longrightarrow\left[\mathrm{learning~alg~(\mathcal{H})}\right]\longrightarrow\mathfrak{h}
$$  

Keep in mind that hhas parameters. The learning algorithm itself may have its own parameters, and such parameters are often called hyperparameters . The analytical solutions presented above for linear regression, e.g., Eq. 2.8, may be thought of as learning algorithms, where $\uplambda$ is a hyperparameter that governs how the learning algorithm works and can strongly affect its performance.  

How should we evaluate the performance of a learning algorithm? This can be tricky. There are many potential sources of variability in the possible result of computing test error on a learned hypothesis h:  

• Which particular training examples occurred in $\mathcal{D}_{\mathfrak{n}}$ • Which particular testing examples occurred in $\mathrm{{{\mathcal{D}}_{n^{\prime}}}}$ • Randomization inside the learning algorithm itself  

It’s a bit funny to interpret the analytical formulas given above for θas “training,” but later when we employ more statistical methods “training” will be ameaningful concept.  

There are technical definitions of these concepts that are studied in more advanced treatments of machine learning. Structural error is referred to as bias and estimation error is referred to as variance .  

# 2.7.2.1 Validation  

Generally, to evaluate how well a learning algorithm works, given an unlimited data source, we would like to execute the following process multiple times:  

• Train on a new training set (subset of our big data source)   
• Evaluate resulting hon a validation set that does not overlap the training set (but is still a subset of our same big data source)  

Running the algorithm multiple times controls for possible poor choices of training set or unfortunate randomization inside the algorithm itself.  

# 2.7.2.2 Cross validation  

One concern is that we might need a lot of data to do this, and in many applications data is expensive or difficult to acquire. We can re-use data with cross validation (but it’s harder to do theoretical analysis).  

CROSS -V ALIDATE $\left({\mathcal{D}},{\mathsf{k}}\right)$  

1 divide $\mathcal{D}$ into $\mathtt{k}$ chunks $\mathcal{D}_{1},\mathcal{D}_{2},\ldots\mathcal{D}_{\boldsymbol{\mathsf{k}}}$ (of roughly equal size)   
2 for $i=1$ to $\mathtt{k}$   
3 train $\mathfrak{h}_{\mathrm{i}}$ on $\Phi\setminus\mathcal{D}_{\mathrm{i}}$ (withholding chunk $\Phi_{\mathrm{i}}$ as the validation set)   
4 compute “test” error $\mathcal{E}_{\mathrm{i}}(\mathfrak{h}_{\mathrm{i}})$ on withheld data $\Phi_{\mathrm{i}}$   
5 return $\frac{1}{{\sf k}}\,\bar{\sum}_{\mathrm{i}=1}^{\boldsymbol{\up k}}\,\mathcal{E}_{\mathrm{i}}({\sf h}_{\mathrm{i}})$ P  

It’s very important to understand that (cross-)validation neither delivers nor evaluates a single particular hypothesis h. It evaluates the learning algorithm that produces hypotheses.  

# 2.7.2.3 Hyperparameter tuning  

The hyper-parameters of a learning algorithm affect how the algorithm works but they are not part of the resulting hypothesis. So, for example, $\uplambda$ in ridge regression affects which hypothesis will be returned, but $\lambda$ itself doesn’t show up in the hypothesis (the hypothesis is specified using parameters θand $\uptheta_{0}$ ).  

You can think about each different setting of a hyper-parameter as specifying a different learning algorithm.  

In order to pick a good value of the hyper-parameter, we often end up just trying a lot of values and seeing which one works best via validation or cross-validation.  

Study Question: How could you use cross-validation to decide whether to use analytic ridge regression or our random-regression algorithm and to pick Kfor random regression or $\lambda$ for ridge regression?  